﻿#if UNITY_EDITOR_OSX || (UNITY_STANDALONE_OSX && !UNITY_EDITOR)
public partial class AkBasePathGetter
{
	static string DefaultPlatformName = "Mac";
}
#endif